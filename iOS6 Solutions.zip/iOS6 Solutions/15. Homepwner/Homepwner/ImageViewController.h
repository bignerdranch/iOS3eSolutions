//
//  ImageViewController.h
//  Homepwner
//
//  Created by Joe Conway on 11/28/12.
//  Copyright (c) 2012 Big Nerd Ranch. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageViewController : UIViewController
@property (nonatomic, strong) UIImage *image;
@end
