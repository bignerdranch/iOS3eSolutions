//
//  BNRLine.m
//  TouchTracker
//
//  Created by Joe Conway on 12/26/12.
//  Copyright (c) 2012 Big Nerd Ranch. All rights reserved.
//

#import "BNRLine.h"

@implementation BNRLine

@end
